import React, { useState } from 'react';
import './App.css';

var jobs = ["전사", "마법사", "궁수", "도적", "사제"];
var grade = ["SSR", "SR", "S", "R", "H", "N"];

function dice(s, e) {
  return Math.floor(Math.random() * (e - s + 1)) + s;
}

function Card({ job, grade }) {
  return (
    <div className={`card ${job} ${grade}`}>
      {job} - {grade} {/* job과 grade를 표시 */}
    </div>
  );
}

function CardArea({ children }) {
  return (
    <div id='card_area'>
      {children}
    </div>
  );
}

function App() {
  const [my, setMy] = useState([]);

  const [party] = useState([
    { job: '전사', grade: 'SSR' },
    { job: '마법사', grade: 'SR' },
    { job: '궁수', grade: 'S' },
    { job: '전사', grade: 'R' },
    { job: '궁수', grade: 'H' }
  ]);

  // 카드 등급을 한 단계 올리는 함수
  function upgradeGrade(grade) {
    const gradeOrder = ["N", "H", "R", "S", "SR", "SSR"];
    const index = gradeOrder.indexOf(grade);
    if (index < 5) {
      return gradeOrder[index + 1]; // 한 단계 올린 등급 반환
    }
    return grade; // 이미 최고 등급이면 그대로 반환
  }

  // 같은 직업, 같은 등급 카드 합성
  function handleFusion() {
    const updatedCards = [...my]; // my 상태를 복사

    const newCards = [];

    // 각 직업별로 카드들을 그룹화
    const groupedCards = my.reduce((acc, card) => {
      const key = `${card.job}-${card.grade}`;
      if (!acc[key]) acc[key] = [];
      acc[key].push(card);
      return acc;
    }, {});

    // 그룹별로 합성 작업
    for (const key in groupedCards) {
      const cards = groupedCards[key];
      if (cards.length >= 2) {
        // 2장 이상의 카드가 있을 경우
        const [card1, card2] = cards;

        // 두 카드를 합성해서 새로운 등급 카드 생성
        const newGrade = upgradeGrade(card1.grade);
        const newCard = { job: card1.job, grade: newGrade };

        // 합성된 카드는 새로운 카드 배열에 추가
        newCards.push(newCard);

        // 합성된 카드는 원래 목록에서 제외
        const remainingCards = my.filter(card => card !== card1 && card !== card2);
        updatedCards.length = 0; // 기존 updatedCards 비우기
        updatedCards.push(...remainingCards, ...newCards); // 합성된 카드 추가
      }
    }

    // 상태를 새 카드들로 업데이트
    setMy(updatedCards);
  }

  // 10연차 뽑기
  function gacha10() {
    let newCards = [];
    for (let i = 0; i < 10; i++) {
      const j = jobs[dice(0, 4)];
      const g = grade[dice(0, 5)];
      newCards.push({ job: j, grade: g });
    }
    setMy([...my, ...newCards]);
  }

  // 카드 1개 뽑기
  function gacha() {
    const j = jobs[dice(0, 4)];
    const g = grade[dice(0, 5)];
    setMy([...my, { job: j, grade: g }]);
  }
 

   

  return (
    <>
     <h2>파티 1</h2>
      <CardArea>
        {party.map((character, index) => (
          <Card key={index} job={character.job} grade={character.grade} />
        ))}
      </CardArea>
      <h2>보유 카드</h2>
      <CardArea>
        {my.map((character, index) => (
          <Card key={index} job={character.job} grade={character.grade} />
        ))}
      </CardArea>

      <button onClick={gacha}>카드 1뽑</button>
      <button onClick={gacha10}>10연챠</button>
      <button onClick={handleFusion}>카드 합성</button>

      <h2>적</h2>
      <CardArea>
        {/* 적 파티 예시 */}
        <Card key="0" job="전사" grade="SSR" />
        <Card key="1" job="마법사" grade="SR" />
        <Card key="2" job="궁수" grade="S" />
      </CardArea>
    </>
  );
}

export default App;
