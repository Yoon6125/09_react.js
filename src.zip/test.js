import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [showCat, setShowCat] = useState(true);

  const toggleCat = () => {
    setShowCat(!showCat);
  };

  return (
    <div>
      <button onClick={toggleCat}>
        {showCat ? '고양이 없애기' : '고양이 보여주기'}
      </button>
      {showCat && <Cat />}
    </div>
  );
}

function Cat() {
  useEffect(() => {
    console.log('Cat 컴포넌트가 생성됨'); // 컴포넌트가 생성될 때 실행

    return () => {
      console.log('Cat 컴포넌트가 제거됨'); // 컴포넌트가 제거될 때 실행
    };
  }, []);

  return <p>야옹</p>;
}

export default App;
