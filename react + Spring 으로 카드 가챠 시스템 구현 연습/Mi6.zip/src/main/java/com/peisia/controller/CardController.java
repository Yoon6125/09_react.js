package com.peisia.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.peisia.dto.CardDto;
import com.peisia.service.CardService;

import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/card/*")
@RestController
@AllArgsConstructor
public class CardController {

	@Setter(onMethod_ = @Autowired)
	private CardService service;

	@GetMapping("/play")
	public ArrayList<CardDto> play() {
		ArrayList<CardDto> n = service.getList();
		System.out.println("총 카드 수:" + n.size());
		return n;
	}

}
