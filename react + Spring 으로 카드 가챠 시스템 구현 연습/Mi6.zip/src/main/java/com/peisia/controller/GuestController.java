package com.peisia.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.peisia.dto.GuestDto;
import com.peisia.dto.MemberDto;
import com.peisia.service.GuestService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/guest/*")
@Controller
@AllArgsConstructor
public class GuestController {
	private GuestService service;

	@GetMapping({ "/getList", "/getSearchList" })
	public void getList(Model model, @RequestParam(value = "currentPage", defaultValue = "1") int currentPage,
			@RequestParam(value = "searchWord", defaultValue = "null") String searchWord, HttpServletRequest request) {
		String path = request.getContextPath();
		String keyword = request.getParameter("searchWord");
		model.addAttribute("blp", service.getList(currentPage, path, keyword));
	}

	@GetMapping({ "/read", "/modify" })
	public void read(@RequestParam("bno") long bno, Model model) {
		model.addAttribute("read", service.read(bno));
	}

	@GetMapping("/del")
	public String del(@RequestParam("bno") long bno) {
		service.del(bno);
		return "redirect:/guest/getList";
	}

	@GetMapping("/write")
	public void write() {

	}

	@PostMapping("/write")
	public String write(GuestDto dto) {
		service.write(dto);
		return "redirect:/guest/getList";
	}

	@PostMapping("/modify")
	public String modify(GuestDto dto) {
		service.modify(dto);
		return "redirect:/guest/getList";
	}

	@GetMapping("/register")
	public void register() {

	}

	@PostMapping("/register")
	public String register(MemberDto md) {
		service.register(md);
		return "redirect:/";
	}

	@GetMapping("/login")
	public void login() {

	}

	@PostMapping("/login")
	public String login(MemberDto md, HttpSession session) {
		session.setAttribute("loginid", service.login(md));
		return "redirect:/";
	}

	@PostMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}

	// 중복 계정 생성 방지 (미구현)
	@PostMapping("/selectId")
	public void selectId(Model model, String bid) {

		model.addAttribute("selectId", service.selectId(bid));
		System.out.println("동작됨");
		System.out.println(bid);
	}

}
