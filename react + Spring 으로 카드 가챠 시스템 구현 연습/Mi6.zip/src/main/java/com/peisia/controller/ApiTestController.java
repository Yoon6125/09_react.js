package com.peisia.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.peisia.dto.Animal;
import com.peisia.dto.ApiTest;

@RequestMapping("/apitest/*")
@RestController
public class ApiTestController {

	@GetMapping("/testOne")
	public ApiTest gettest() {
		ApiTest test = new ApiTest("테스트", "만드는", 7);
		test.testList.add("중");
		test.testList.add("시험 만드는 중");
		test.testList.add("시험 하는 중");

		test.testAnimal.add(new Animal("시험개", 8));

		return test;
	}

}
