package com.peisia.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.peisia.dto.CardDto;
import com.peisia.mapper.CardMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class CardServiceImpl implements CardService {

	@Setter(onMethod_ = @Autowired)
	private CardMapper mapper;

	@Override
	public ArrayList<CardDto> getList() {
		return mapper.getList();
	}

	@Override
	public void addCard(CardDto c) {
		mapper.addCard(c);
	}

}
