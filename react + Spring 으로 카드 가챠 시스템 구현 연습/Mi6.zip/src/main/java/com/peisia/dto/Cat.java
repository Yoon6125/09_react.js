package com.peisia.dto;

import java.util.ArrayList;

public class Cat {
	String name;
	Integer age;

	public ArrayList<String> hobby = new ArrayList<String>();
	public ArrayList<Animal> friend = new ArrayList<Animal>();

	public Cat(String name, Integer age) {
		super();
		this.name = name;
		this.age = age;
	}

}
