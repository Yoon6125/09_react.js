package com.peisia.dto;

import java.util.ArrayList;

public class ApiTest {
	String test;
	String make;
	Integer al;

	public ArrayList<String> testList = new ArrayList<String>();
	public ArrayList<Animal> testAnimal = new ArrayList<Animal>();

	public ApiTest(String test, String make, Integer al) {
		this.test = test;
		this.make = make;
		this.al = al;
	}

}
