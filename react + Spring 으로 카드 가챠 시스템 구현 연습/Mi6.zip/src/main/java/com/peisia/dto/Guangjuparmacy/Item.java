package com.peisia.dto.Guangjuparmacy;

public class Item {
	public String stationName; // 문화 노선도
	public String dstncDt; // 거리(m)
	public String apvPermVmd; // 인허가일자
	public String bplcNm; // 사업자명
	public String dtlStateGbn; // 상세영업상태 코드
	public String dtlStateNm; // 상세영업상태명
	public String latitude; // 위도
	public String longitude; // 경도
	public String mgtNo; // 관리번호
	public String rdnWhlAddr; // 도로명전체 주소
	public String trdStateGbn; // 영업상태구분표
	public String trdStateNm; // 영업 상태명
	public String updateDt; // 데이터갱신 구분
	public String updateGbn; // 데이터 갱신 일자
}
