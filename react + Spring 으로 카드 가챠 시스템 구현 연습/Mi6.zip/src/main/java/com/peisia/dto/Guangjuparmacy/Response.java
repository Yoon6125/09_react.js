package com.peisia.dto.Guangjuparmacy;

import com.peisia.dto.Body;
import com.peisia.dto.Header;

public class Response {
	public Header header;
	public Body body;
}
