package com.peisia.dto.Guangjuparmacy;

import com.peisia.dto.Response;

public class ParmacyDto {
	public Response response;
}
