
package com.peisia.MHW.charmDto;

public class Skill {

	public Integer id;
	public Integer level;
	public Modifiers modifiers;
	public String description;
	public Integer skill;
	public String skillName;

}
