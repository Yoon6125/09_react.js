
package com.peisia.MHW.charmDto;

import java.util.List;

public class Crafting {

	public Boolean craftable;
	public List<Material> materials;

}
