package com.peisia.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.peisia.dto.WealthDto;
import com.peisia.mapper.ShopMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class ShopServiceImpl implements ShopService {

	@Setter(onMethod_ = @Autowired)
	private ShopMapper mapper;

	@Transactional
	@Override
	public void buyDice() {
		mapper.buyDice();
		mapper.payGold();
	}

	@Override
	public void buyGold() {
		mapper.buyGold();
	}

	@Override
	public WealthDto getWealth() {
		return mapper.getWealth();
	}

	@Override
	public void payGold() {
		mapper.payGold();
	}

}
