package com.peisia.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.peisia.dto.CardDto;
import com.peisia.dto.SelectCardDto;
import com.peisia.mapper.CardMapper;
import com.peisia.mapper.ShopMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class CardServiceImpl implements CardService {

	@Setter(onMethod_ = @Autowired)
	private CardMapper mapper;
	@Setter(onMethod_ = @Autowired)
	private ShopMapper shopmapper;

	@Override
	public ArrayList<CardDto> getList() {
		return mapper.getList();
	}

	@Transactional
	@Override
	public void addCard(CardDto c) {
		mapper.addCard(c);
		shopmapper.payDice();
	}

	@Override
	public void pjMemberAdd(SelectCardDto c) {
		mapper.pjMemberAdd(c);
	}

	@Override
	public void resetPjMember() {
		mapper.resetPjMember();
	}

//	@Override
//	public void partyDismiss(String job, String grade) {
//		mapper.partyDismiss(new CardDto(job, grade));
//	}

	@Override
	public ArrayList<CardDto> getPjMember(int no) {
		return mapper.getPjMember(no);
	}

}
