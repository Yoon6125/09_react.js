package com.peisia.dto;

import lombok.Data;

@Data
public class WealthDto {
	private int gold;
	private int dice;
	private String id;
}
