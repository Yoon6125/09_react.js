package com.peisia.dto.Guangjuparmacy;

public class Header {
	public String resultCode;
	public String resultMsg;
}
