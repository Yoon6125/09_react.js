package com.peisia.dto.Guangjuparmacy;

import java.util.List;

public class Items {
	public List<Item> item;
}
