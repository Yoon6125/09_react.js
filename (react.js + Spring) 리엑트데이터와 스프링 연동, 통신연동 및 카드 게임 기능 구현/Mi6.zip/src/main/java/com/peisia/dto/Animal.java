package com.peisia.dto;

import java.util.ArrayList;

public class Animal {
	String name;
	Integer age;

	public ArrayList<String> hobby = new ArrayList<String>();
	public ArrayList<Animal> friend = new ArrayList<Animal>();

	public Animal(String name, Integer age) {
		super();
		this.name = name;
		this.age = age;
	}

}
