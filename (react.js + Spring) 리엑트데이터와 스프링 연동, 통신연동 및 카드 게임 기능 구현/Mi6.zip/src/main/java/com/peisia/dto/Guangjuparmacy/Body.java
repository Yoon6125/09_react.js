package com.peisia.dto.Guangjuparmacy;

public class Body {
	public Items items;
	public String numOfRows;
	public String pageNo;
	public String totalCount;
}
