package com.peisia.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.peisia.dto.CardDto;
import com.peisia.dto.SelectCardDto;
import com.peisia.service.CardService;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/card/*")
@RestController
public class CardController {

	@Setter(onMethod_ = @Autowired)
	private CardService service;

	@RequestMapping("/play")
	public ArrayList<CardDto> play() {
		ArrayList<CardDto> n = service.getList();
		System.out.println("총 카드 수:" + n.size());
		return n;
	}

	@RequestMapping("/pjMemberAdd")
	public void pjMemberAdd(@RequestBody SelectCardDto c) {
//		CardDto c = new CardDto((String) requestData.get("job"), (String) requestData.get("grade"));
		service.pjMemberAdd(c);
//		System.out.println("데이터 수신 로그 직업:" + requestData.get("job"));
//		System.out.println("데이터 수신 로그 등급:" + requestData.get("grade"));
		System.out.println("========리엑트에서 받아온 id 데이터 :" + c.getId());
		System.out.println("========리엑트에서 받아온 no 데이터 :" + c.getNo());
	}

	@RequestMapping("/resetPjMember")
	public void resetPjMember() {
		service.resetPjMember();
	}

//	@RequestMapping("/partyDismiss")
//	public void partyDismiss(@RequestBody Map<String, Object> requestData) {
////		CardDto c = new CardDto((String) requestData.get("job"), (String) requestData.get("grade"));
//		service.partyDismiss((String) requestData.get("job"), (String) requestData.get("grade"));
//		System.out.println("데이터 수신 로그 직업:" + requestData.get("job"));
//		System.out.println("데이터 수신 로그 등급:" + requestData.get("grade"));
//	}

	@RequestMapping("/getPjMember")
	public ArrayList<CardDto> getPjMember(@RequestParam("no") int no) {
		ArrayList<CardDto> n = service.getPjMember(no);
		System.out.println("=====pj 멤버 수:" + n.size());
		return n;
	}

}
