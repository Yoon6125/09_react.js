package com.peisia.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.peisia.dto.Guangjuparmacy.ParmacyDto;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Controller
@RequestMapping("/Parmacy/*")
@AllArgsConstructor
public class ParmacyController {

	@RequestMapping("/p")
	public void p(Model model) {
		//// 우리나라 공공 api ////
		// 인코딩 인증키
		String NameOfStation = "상무";
		String a = koreanToUrlHex(NameOfStation);

		String API_KEY = "3Kl6s/q9OlgACIbag1YNGTgx5Ydu725jt8w0/CloZObmw1Dn6fRHoCtgtGOrHm7iiCbTRA03RWxdLyrAh/WjSw==";
		String API_URL = String.format(
				"http://apis.data.go.kr/B551232/OAMS_PARMACY_01/GET_OAMS_PARMACY_01?serviceKey=%s&pageNo=2&numOfRows=4&STATION_NAME=%s",
				API_KEY, a);

		RestTemplate restTemplate = new RestTemplate();

		//// **** 중요 **** uri
		URI uri = null; // java.net.URI 임포트 하셈
		try {
			uri = new URI(API_URL); // URI 클래스는 URL에 대한 유효성 검사, 구성요소 추출, 보안(특수문자, 공백 처리 등)을 도와줌
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}

		/*
		 * String s = restTemplate.getForObject(uri, String.class);
		 * log.info("==========뭐 나오냐? : " + s);
		 */

		ParmacyDto pd = restTemplate.getForObject(uri, ParmacyDto.class);
		log.info("======json========: 데이터 잘 나옴? :" + pd.response.body.dataType);
		/*
		 * String s = restTemplate.getForObject(uri, String.class); //
		 * log.info("====== 우리나라 날씨 잘 나오나? " + s);
		 * 
		 * KWeatherDto kw = restTemplate.getForObject(uri, KWeatherDto.class); // 자기
		 * 클래스로 바꾸시오.. log.info("==== json ==== : 우리나라 날씨 잘 나오냐? : " +
		 * kw.response.body.dataType); log.info("==== json ==== : 우리나라 날씨 잘 나오냐? : " +
		 * kw.response.body.dataType); String location =
		 * kw.response.body.items.item.get(0).stnNm; String tMin =
		 * kw.response.body.items.item.get(0).minTa; String tMax =
		 * kw.response.body.items.item.get(0).maxTa; String ddara = String.
		 * format("==== json ==== : 어제의 날씨입니다~ 어제 %s 의 최저기온은 %s 도 최고 기온은 %s 였습니다. 날씨였습니다."
		 * , location, tMin, tMax); log.info(ddara); model.addAttribute("location",
		 * location); model.addAttribute("tMin", tMin); model.addAttribute("tMax",
		 * tMax); model.addAttribute("ddara", ddara);
		 */
	}

	public String koreanToUrlHex(String stationName) {
		String convertName = stationName;

		// 한글 문자열을 utf-8로 변환하고 각 바이트를 url 인코딩된 16진수로 변환
		StringBuilder hexString = new StringBuilder();
		byte[] bytes = convertName.getBytes(StandardCharsets.UTF_8);
		for (byte b : bytes) {
			hexString.append(String.format("%%%02X", b));
		}

		return hexString.toString();
	}
}
