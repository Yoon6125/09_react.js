import axios from 'axios';
import React, { useState, useEffect, useCallback } from 'react';
import './App.css';

// var jobs = ["전사", "마법사", "궁수", "도적", "사제"];
// var grade = ["SSR", "SR", "S", "R", "H", "N"];

// function dice(s, e) {
//   return Math.floor(Math.random() * (e - s + 1)) + s;
// }

function Card({ job, grade ,xxx }) {
  return (
    <div className={`card ${job} ${grade}`} onClick={xxx}  >
      {job} - {grade} {/* job과 grade를 표시 */}
    </div>
  );
}
// function map(val, minA, maxA, minB, maxB) {
//   return minB + ((val - minA) * (maxB - minB)) / (maxA - minA);
// }

// function Card3D(card, ev) {
//   let img = card.querySelector('img');
//   let imgRect = card.getBoundingClientRect();
//   let width = imgRect.width;
//   let height = imgRect.height;
//   let mouseX = ev.offsetX;
//   let mouseY = ev.offsetY;
//   let rotateY = map(mouseX, 0, 180, -25, 25);
//   let rotateX = map(mouseY, 0, 250, 25, -25);
//   let brightness = map(mouseY, 0, 250, 1.5, 0.5);
  
//   img.style.transform = `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
//   img.style.filter = `brightness(${brightness})`;
// }

// var cards = document.querySelectorAll('.card3d');

// cards.forEach((card) => {
//   card.addEventListener('mousemove', (ev) => {
//     Card3D(card, ev);
//   });
  
//   card.addEventListener('mouseleave', (ev) => {
//     let img = card.querySelector('img');
    
//     img.style.transform = 'rotateX(0deg) rotateY(0deg)';
//     img.style.filter = 'brightness(1)';
//   });
// });

function CardArea({ children }) {
  return (
    <div id='card_area'>
      {children}
    </div>
  );
}

function App() {
  var [dice, setDice] = useState(0);
  var [gold, setGold] = useState(0);

  function resetPj(){
    setPj([]);
    resetPjApi();
  }
  
  
  useEffect(()=>{
    console.log('컴포넌트 마운트');
    getMyWealth();
    getMyCardApi();
    getPjApi();
    return ()=>{
      console.log('컴포넌트 언마운트');
    };
  }, []);
  
  var [my, setMy] = useState([]);

  const [pj , setPj] = useState([]);
  
  // function partyDismiss(d , excludeIndex){
  //   setParty(...party.filter(card => card.index !== excludeIndex));
  //   partyDismissApi(d);
  // }

  
  // getMyCardApi();

 
  function pjMemberAdd(d){
    axios.post('http://localhost:8080/spring/card/pjMemberAdd',d)
    .then(response =>{
      console.log(response.data); 
    })
    .catch(error =>{
      console.error('Error fetching data:', error);
    });
  }
   //파티 구성 초기화 버튼 DB 통신
   function resetPjApi(){
    axios.post('http://localhost:8080/spring/card/resetPjMember')
    .then(response =>{
      console.log(response.data); 
    })
    .catch(error =>{
      console.error('Error fetching data:', error);
    });
    }
  // function partyDismissApi(d){
  //   axios.post('http://localhost:8080/spring/card/partyDismiss',d)
  //   .then(response =>{
  //     console.log(response.data); 
  //   })
  //   .catch(error =>{
  //     console.error('Error fetching data:', error);
  //   });
  // }
  var getMyWealth = useCallback(() =>{
    axios.post('http://localhost:8080/spring/shop/getWealth')
    .then(response =>{
      console.log(response.data); 
      setGold(response.data.gold);
      setDice(response.data.dice);
    })
    .catch(error =>{
      console.error('Error fetching data:', error);
    });
  }, []);

  function buyGold(){
    axios.post('http://localhost:8080/spring/shop/buyGold')
    .then(response =>{
      console.log(response.data); 
      getMyWealth();
    })
    .catch(error =>{
      console.error('Error fetching data:', error);
    });
  }
  function buyDice(){
    axios.post('http://localhost:8080/spring/shop/buyDice')
    .then(response =>{
      console.log(response.data); 
      getMyWealth();
    })
    .catch(error =>{
      console.error('Error fetching data:', error);
    });
  }
  


  function cat(index , job , grade , no){
    if(pj.length >= 5){
      alert('파티원은 최대 5명끼지 추가할수 있습니다.');
      return;
    }
    console.log(`보유카드 번호: ${index} 고유 no : ${no}`);
    // alert(`보유카드 번호: ${index} 직업: ${job} 등급:${grade}`);
    // var d = {job: job, grade: grade};
    var d = {id:'cat', no: no};
    // setPj([...pj,d]);
  

    //디비에 파티 추가 api 호출
    pjMemberAdd(d);
    
  }
  // function cat2(index , job , grade){
  //   console.log(`보유카드 번호: ${index}`);
  //   alert(`보유카드 번호: ${index} 직업: ${job} 등급:${grade}`);
  //   var d = {index: index ,job: job, grade: grade};
    

  //   //디비에 파티 추가 api 호출
  //   partyDismiss(d ,index);
  // }

  // 카드 등급을 한 단계 올리는 함수
  // function upgradeGrade(grade) {
  //   const gradeOrder = ["N", "H", "R", "S", "SR", "SSR"];
  //   const index = gradeOrder.indexOf(grade);
  //   if (index < 5) {
  //     return gradeOrder[index + 1]; // 한 단계 올린 등급 반환
  //   }
  //   return grade; // 이미 최고 등급이면 그대로 반환
  // }

  // // 같은 직업, 같은 등급 카드 합성
  // function handleFusion() {
  //   const updatedCards = [...my]; // my 상태를 복사

  //   const newCards = [];

  //   // 각 직업별로 카드들을 그룹화
  //   const groupedCards = my.reduce((acc, card) => {
  //     const key = `${card.job}-${card.grade}`;
  //     if (!acc[key]) acc[key] = [];
  //     acc[key].push(card);
  //     return acc;
  //   }, {});

  //   // 그룹별로 합성 작업
  //   for (const key in groupedCards) {
  //     const cards = groupedCards[key];
  //     if (cards.length >= 2) {
  //       // 2장 이상의 카드가 있을 경우
  //       const [card1, card2] = cards;

  //       // 두 카드를 합성해서 새로운 등급 카드 생성
  //       const newGrade = upgradeGrade(card1.grade);
  //       const newCard = { job: card1.job, grade: newGrade };

  //       // 합성된 카드는 새로운 카드 배열에 추가
  //       newCards.push(newCard);

  //       // 합성된 카드는 원래 목록에서 제외
  //       const remainingCards = my.filter(card => card !== card1 && card !== card2);
  //       updatedCards.length = 0; // 기존 updatedCards 비우기
  //       updatedCards.push(...remainingCards, ...newCards); // 합성된 카드 추가
  //     }
  //   }

  //   // 상태를 새 카드들로 업데이트
  //   setMy(updatedCards);
  // }

  // // 10연차 뽑기
  // function gacha10() {
  //   let newCards = [];
  //   for (let i = 0; i < 10; i++) {
  //     const j = jobs[dice(0, 4)];
  //     const g = grade[dice(0, 5)];
  //     newCards.push({ job: j, grade: g });
  //   }
  //   setMy([...my, ...newCards]);
  // }

  // // 카드 1개 뽑기
  // function gacha() {
  //   const j = jobs[dice(0, 4)];
  //   const g = grade[dice(0, 5)];
  //   setMy([...my, { job: j, grade: g }]);
  // }
  
  //DB 서버로 통신
  function gachaApi(){
    axios.get('http://localhost:8080/spring/api/gacha')			
    .then(response => {		
      console.log(response.data);  // 서버로부터 받은 데이터 출력	
          // 기존의 `my` 배열을 복사하고, 새 객체를 추가한 새로운 배열로 업데이트
      setMy([...my, response.data]);
      getMyWealth();
    })		
    .catch(error => {		
      console.error('Error fetching data:', error);  // 에러 처리	
    });		
  }

  //DB 서버로 통신
  var getMyCardApi = useCallback(()=>{
    axios.get('http://localhost:8080/spring/card/play')			
    .then(response => {		
      console.log(response.data);  // 서버로부터 받은 데이터 출력	
          // 기존의 `my` 배열을 복사하고, 새 객체를 추가한 새로운 배열로 업데이트
      setMy(response.data);
    })		
    .catch(error => {		
      console.error('Error fetching data:', error);  // 에러 처리	
    });		
  } ,[]);

  //DB 서버로 통신 (10연차)
  function gachaApi10(){
    axios.get('http://localhost:8080/spring/api/gacha10')
    .then(response => {
      console.log(response.data); //서버로 부터 받은 데이터 출력

      setMy([...my,...response.data]);
    })
    .catch(error =>{
      console.error('Error fetching data:', error);
    });
  }

  var getPjApi = useCallback(()=>{
    axios.get('http://localhost:8080/spring/card/getPjMember?no=1')
   .then(response =>{
      console.log(response.data);
      setPj(response.data);
   })
   .catch(error =>{
    console.error('에러:',error); 
   });
  }, []);
 

  

  return (
    <>
     <h2>pj 1</h2>
      <CardArea>
        {pj.map((character, index) => (
           <Card key={index} job={character.job} grade={character.grade}  />
        ))}
      </CardArea>
      <br></br>
      <button onClick={resetPj}>참여인원 비우기</button>
      <h2>보유 카드</h2>
      <CardArea>
        {my.map((character, index) => (
          <Card key={index} job={character.job} grade={character.grade} xxx={()=>cat(index ,character.job , character.grade , character.no)} />
        ))}
      </CardArea>

      {/* <button onClick={gacha}>카드 1뽑</button>
      <button onClick={gacha10}>10연챠</button> */}
      <button onClick={gachaApi}>단뽑(Api)</button>
      {/* <button onClick={getMyCardApi}>카드 목록 가져오기</button> */}
      <button onClick={gachaApi10}>10연차(Api)</button>
      {/* <button onClick={handleFusion}>카드 합성</button> */}
      <fieldset>
        <legend>상점</legend>
        <p>{dice}🎲</p>
        <p>{gold}💰</p>
        <button onClick={buyDice}>주사위 상자 구매</button>
        <button onClick={buyGold}>골드 충전</button>
      </fieldset>

      <h2>적</h2>
      <CardArea>
        {/* 적 파티 예시 */}
        <Card key="0" job="전사" grade="SSR" />
        <Card key="1" job="마법사" grade="SR" />
        <Card key="2" job="궁수" grade="S" />
      </CardArea>
    </>
  );
}

export default App;
